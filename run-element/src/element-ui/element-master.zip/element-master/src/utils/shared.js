export function isDef(val) {
  return val !== undefined && val !== null;
}
